# gFur Information

Unfortunately we are not able to further support gFur in terms of bug-fixing and porting to new UE versions.

We have already put a lot of effort into gFur and we feel like it should have a chance if people find it useful.

For now this is the best we figured out so far (this is not a license, license is provided in a separate file):
- gFur is now open source
- it's free for non-commercial use
- in a hope to get it back on track and work with UE5.XX we will grant free commercial licenses to meaningful donations of bug-fixes and updates that make it work in latest UE versions
- if you are interested in a commercial license without donating fixes/updates, contact us at gfur@gim.studio
