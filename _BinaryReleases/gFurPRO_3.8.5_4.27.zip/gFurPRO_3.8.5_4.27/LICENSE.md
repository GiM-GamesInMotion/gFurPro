# gFur License

> Version 1.0, January 2023
> 
> Copyright (C) 2023 GiM s.r.o.
> 
> TERMS AND CONDITIONS

1. gFur code is provided with no warranty and support. Use at your own risk. Currently the code should compile for UE5.0 and should run in UE5.0 but is not usable due to bugs. 
2. We grant you a license to use the gFur code/plugin in any non-commercial project as a plugin for Unreal Engine free of charge.
3. You can't use the gFur code/plugin in a commercial project without a commercial license.
4. You can't make a derivative plugin with similar functionality, use parts of the code in another plugin or software, or just rename/modify the code/plugin and sell it or distribute it in any way.
5. We (GiM, s.r.o.) keep full ownership of the gFur code and plugin.
